﻿// ********************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,04.04.2019</created>
/// <changed>ʆϒʅ,10.04.2019</changed>
// ********************************************************************************

// LibraryUsage.cpp : Defines the entry point for the application.
//


#include "StaticAndSharedLibrary.h"


int main ()
{
  Student one ( "John" );
  one.Print ();
  return 0;
}
