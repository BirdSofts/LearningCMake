﻿// ********************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,03.04.2019</created>
/// <changed>ʆϒʅ,30.07.2019</changed>
// ********************************************************************************

// HelloCMake.h : Include file for standard system include files,
// or project specific include files.

#ifndef HELLOCMAKE_H
#define HELLOCMAKE_H


#include <iostream>


#endif // !HELLOCMAKE_H

// TODO: Reference additional headers your program requires here.
