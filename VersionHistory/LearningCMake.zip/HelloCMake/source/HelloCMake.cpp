﻿// ********************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,03.04.2019</created>
/// <changed>ʆϒʅ,10.04.2019</changed>
// ********************************************************************************

// HelloCMake.cpp : Defines the entry point for the application.
//


#include "HelloCMake.h"


int main ()
{
  std::cout << "Hello CMake." << std::endl;
  std::cin.get ();
  return 0;
}
