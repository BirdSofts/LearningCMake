﻿// ********************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,03.04.2019</created>
/// <changed>ʆϒʅ,10.04.2019</changed>
// ********************************************************************************

// HelloCMake.h : Include file for standard system include files,
// or project specific include files.

#pragma once


#include <iostream>

// TODO: Reference additional headers your program requires here.
